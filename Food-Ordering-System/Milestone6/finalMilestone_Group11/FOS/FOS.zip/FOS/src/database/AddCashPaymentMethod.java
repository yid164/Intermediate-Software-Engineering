package database;
/**
 * Create by Yinsheng Dong
 */
public class AddCashPaymentMethod
{
}
